package com.dockermysql.dockermysql;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DockerMysqlApplicationTests {

	@Test
	void contextLoads() {
	}

}
