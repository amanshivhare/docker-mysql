package com.dockermysql.dockermysql.controllers;

import com.dockermysql.dockermysql.entity.DemoEntity;
import com.dockermysql.dockermysql.service.DemoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/docker")
public class DockerController {

    @Autowired
    private DemoService demoService;

    @GetMapping("testApi")
    public String testMethod() {
        return "Working fine..";
    }

    @PostMapping(path = "/add")
    public ResponseEntity<DemoEntity> add(@RequestBody DemoEntity demoEntity) {
        DemoEntity savedObj = demoService.add(demoEntity);
        return new ResponseEntity<>(savedObj, HttpStatus.OK);
    }

    @GetMapping(path = "/getAll")
    public ResponseEntity<List<DemoEntity>> getAll() {
        List<DemoEntity> list = demoService.getAll();
        return new ResponseEntity<>(list, HttpStatus.OK);
    }
}
