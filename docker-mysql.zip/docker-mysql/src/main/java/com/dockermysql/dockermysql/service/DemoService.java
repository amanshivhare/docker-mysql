package com.dockermysql.dockermysql.service;

import com.dockermysql.dockermysql.entity.DemoEntity;
import com.dockermysql.dockermysql.repository.DemoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DemoService {
    @Autowired
    private DemoRepository demoRepository;

    public DemoEntity add(DemoEntity demoEntity) {
        return demoRepository.save(demoEntity);
    }

    public List<DemoEntity> getAll() {
        return demoRepository.findAll();
    }
}
